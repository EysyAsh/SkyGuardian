﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace SkyGuardian.Models
{
    public class ConexionBD
    {
        private SqlConnection connection;

        public ConexionBD()
        {
            string connectionString = "Server=tiusr11pl.cuc-carrera-ti.ac.cr\\MSSQLSERVER2019;Initial Catalog=tiusr11pl_skyGuardian_Grupo07;User ID=jam-g07;Password=Jam.112002";
            connection = new SqlConnection(connectionString);
        }

        public DataTable ConsultarDatos(string v)
        {
            DataTable dataTable = new DataTable();
            try
            {
                connection.Open();
                string query = @"
                    SELECT 
                        V.NumeroVuelo,
                        A.Nombre AS salida,
                        B.Nombre AS destino,
                        V.FechaSalida AS horaDespegue,
                        P.NumeroPista AS pistaAsignada,
                        E.Estado AS estadoVuelo
                    FROM Vuelos V
                    INNER JOIN AsignacionPistasDespegue AP ON V.IdVuelo = AP.IdVuelo
                    INNER JOIN Pistas P ON AP.IdPista = P.Id
                    INNER JOIN Aeropuerto A ON V.Origen = A.Nombre
                    INNER JOIN Aeropuerto B ON V.Destino = B.Nombre
                    INNER JOIN EstadoAvion E ON V.IdEstadoVuelo = E.IdEstadoAvion
                    WHERE V.NumeroVuelo = @numeroVuelo";  // Añadir un filtro opcional si lo necesitas

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@numeroVuelo", v); // Añadir un parámetro opcional si lo necesitas
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al consultar datos: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return dataTable;
        }

        public DataTable ConsultarAviones()
        {
            DataTable dataTable = new DataTable();
            try
            {
                connection.Open();
                string query = @"
                SELECT 
                    IdAvion,
                    Modelo,
                    Fabricante,
                    AnioFabricacion,
                    CapacidadPasajeros,
                    CapacidadCarga,
                    TipoMotor,
                    Longitud,
                    Envergadura,
                    Altura,
                    CapacidadCombustible
                FROM Aviones";

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al consultar datos de Aviones: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return dataTable;
        }

        public DataTable ConsultarDatosComunicaciones()
        {
            DataTable dataTable = new DataTable();
            try
            {
                connection.Open();
                string query = @"
            SELECT ControladorID, Mensaje, FechaHora
            FROM ComunicacionesControladorAeronave
            ORDER BY FechaHora DESC";

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al consultar datos de comunicaciones: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return dataTable;
        }




        public DataTable ConsultarDatosVuelos()
        {
            DataTable dataTable = new DataTable();
            try
            {
                connection.Open();
                string query = @"
            SELECT DISTINCT
    V.NumeroVuelo AS 'Número de Vuelo',
    A.Nombre AS 'Salida',
    A2.Nombre AS 'Destino',
    V.FechaSalida AS 'Hora de Despegue',
    P.NumeroPista AS 'Pista Asignada',
    EA.Estado AS 'Estado del Vuelo',
    V.IdAvion AS 'IdAvion',  -- Agregamos esta línea
    CASE EA.Estado
        WHEN 'Despegando' THEN 1
        WHEN 'En espera' THEN 2
        WHEN 'Cancelado' THEN 3
        ELSE 0
    END AS 'Número Asignado'
            FROM 
    Vuelos V
JOIN 
    Aeropuerto A ON V.Origen = A.Nombre
JOIN 
    Aeropuerto A2 ON V.Destino = A2.Nombre
JOIN 
    AsignacionPistasDespegue APD ON V.IdVuelo = APD.IdVuelo
JOIN 
    Pistas P ON APD.IdPista = P.Id
JOIN 
    EstadoAvion EA ON V.IdEstadoAIVuelo = EA.IdEstadoAvion";

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al consultar datos de vuelos: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return dataTable;
        }



        public DataTable ConsultarAvionPorId(int idAvion)
        {
            DataTable dataTable = new DataTable();
            try
            {
                connection.Open();
                string query = @"
            SELECT 
                IdAvion,
                Modelo,
                Fabricante,
                AnioFabricacion,
                CapacidadPasajeros,
                CapacidadCarga,
TipoMotor,
Longitud,
Envergadura,
Altura,
IdEstadoAvion,
CapacidadCombustible


            FROM Aviones
            WHERE IdAvion = @idAvion";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@idAvion", idAvion);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al consultar datos del avión: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return dataTable;
        }


       








    }
}

