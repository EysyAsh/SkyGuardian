﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SkyGuardian.Models
{
    public class Vuelo
    {
        public string NumeroVuelo { get; set; }
        public string Origen { get; set; }
        public string Destino { get; set; }
        public DateTime FechaSalida { get; set; }
        public DateTime FechaLlegada { get; set; }
        public int Velocidad { get; set; }
        public int GradoInclinacion { get; set; }
        public float Altitud { get; set; }
    }

    public class Avion
    {
        public int IdAvion { get; set; }
        public string Modelo { get; set; }
        public string Fabricante { get; set; }
        public int AnioFabricacion { get; set; }
        public int CapacidadPasajeros { get; set; }
        public decimal CapacidadCarga { get; set; }
        public string TipoMotor { get; set; }
        public decimal Longitud { get; set; }
        public decimal Envergadura { get; set; }
        public decimal Altura { get; set; }
        public int CapacidadCombustible { get; set; }


    }



    public class pruebaBD
    {
        private string connectionString = "Data Source=tiusr11pl.cuc-carrera-ti.ac.cr.\\MSSQLSERVER2019;Initial Catalog=tiusr11pl_skyGuardian_Grupo07;User ID=jam-g07;Password=Jam.112002";


        public string LeerDespegues()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT idVuelo, TipoEvento, Descripcion, Estado FROM EventosDespegue";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        string result = "";

                        while (reader.Read())
                        {
                            int idVuelo = int.Parse(reader["idVuelo"].ToString());
                            string TipoEvento = reader["TipoEvento"].ToString();
                            string Descripcion = reader["Descripcion"].ToString();
                            string Estado = reader["Estado"].ToString();

                            result += $"idVuelo: {idVuelo}, TipoEvento: {TipoEvento}, Descripcion: {Descripcion}, Estado: {Estado}<br>";
                        }

                        return result;
                    }
                }
            }
        }

     
        public List<Vuelo> LeerVuelos()
        {
            List<Vuelo> vuelos = new List<Vuelo>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT NumeroVuelo FROM Vuelos";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Vuelo vuelo = new Vuelo
                            {
                                NumeroVuelo = reader["NumeroVuelo"].ToString(),

                            };

                            vuelos.Add(vuelo);
                        }
                    }
                }
            }

            return vuelos;
        }


        public Dictionary<string, string> ObtenerOrigenYDestinoPorNumeroVuelo(string numeroVuelo)
        {
            Dictionary<string, string> datosVuelo = new Dictionary<string, string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT Origen, Destino, FechaSalida, FechaLlegada, Velocidad, GradoInclinacion, Altitud FROM Vuelos WHERE NumeroVuelo = @NumeroVuelo";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NumeroVuelo", numeroVuelo);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            datosVuelo["Origen"] = reader["Origen"].ToString();
                            datosVuelo["Destino"] = reader["Destino"].ToString();
                            datosVuelo["FechaSalida"] = reader["FechaSalida"].ToString();
                            datosVuelo["FechaLlegada"] = reader["FechaLlegada"].ToString();
                            datosVuelo["Velocidad"] = reader["Velocidad"].ToString();
                            datosVuelo["GradoInclinacion"] = reader["GradoInclinacion"].ToString();
                            datosVuelo["Altitud"] = reader["Altitud"].ToString();

                        }
                    }
                }
            }

            return datosVuelo;
        }
    

    

        public List<Avion> LeerAviones()
        {
            List<Avion> aviones = new List<Avion>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT IdAvion FROM Aviones";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Avion avion = new Avion
                            {
                                IdAvion = Convert.ToInt32(reader["IdAvion"])
                            };

                            aviones.Add(avion);
                        }
                    }
                }
            }

            return aviones;
        }

        public Dictionary<string, string> ObtenerDatosAvion(int IdAvion)
{
    Dictionary<string, string> datosAvion = new Dictionary<string, string>();

    using (SqlConnection connection = new SqlConnection(connectionString))
    {
        connection.Open();

        string query = "SELECT Modelo, Fabricante, AnioFabricacion, CapacidadPasajeros, CapacidadCarga, TipoMotor, Longitud, Envergadura, Altura, CapacidadCombustible FROM Aviones WHERE IdAvion = @IdAvion";

        using (SqlCommand command = new SqlCommand(query, connection))
        {
            command.Parameters.AddWithValue("@IdAvion", IdAvion);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    datosAvion["Modelo"] = reader["Modelo"].ToString();
                    datosAvion["Fabricante"] = reader["Fabricante"].ToString();
                    datosAvion["AnioFabricacion"] = reader["AnioFabricacion"].ToString();
                    datosAvion["CapacidadPasajeros"] = reader["CapacidadPasajeros"].ToString();
                    datosAvion["CapacidadCarga"] = Convert.ToDecimal(reader["CapacidadCarga"]).ToString();
                    datosAvion["TipoMotor"] = reader["TipoMotor"].ToString();
                    datosAvion["Longitud"] = Convert.ToDecimal(reader["Longitud"]).ToString();
                    datosAvion["Envergadura"] = Convert.ToDecimal(reader["Envergadura"]).ToString();
                    datosAvion["Altura"] = Convert.ToDecimal(reader["Altura"]).ToString();
                    datosAvion["CapacidadCombustible"] = reader["CapacidadCombustible"].ToString();
                }
            }
        }
    }

    return datosAvion;
}


       
}
}


