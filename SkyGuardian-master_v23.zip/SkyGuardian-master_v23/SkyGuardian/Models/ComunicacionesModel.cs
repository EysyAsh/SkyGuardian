using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;

namespace SkyGuardian.Models
{
    public class ComunicacionesModel
    {
        private string connectionString = "Data Source=tiusr26pl.cuc-carrera-ti.ac.cr\\MSSQLSERVER2019;Initial Catalog=tiusr11pl_skyGuardian_Grupo07;User ID=jam-g07;Password=Jam.112002";

        public List<string> ObtenerMensajesComunicaciones()
        {
            List<string> mensajes = new List<string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT IdComunicacion, FechaHora, IdAvion, IdControlador, ContenidoMensaje FROM Comunicaciones";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int idComunicacion = reader.GetInt32(0);
                            DateTime fechaHora = reader.GetDateTime(1);
                            int idAvion = reader.GetInt32(2);
                            int idControlador = reader.GetInt32(3);
                            string contenidoMensaje = reader.GetString(4);

                            mensajes.Add($"IdComunicacion: {idComunicacion}, FechaHora: {fechaHora}, IdAvion: {idAvion}, IdControlador: {idControlador}, ContenidoMensaje: {contenidoMensaje}");
                        }
                    }
                }
            }

            return mensajes;
        }

        public List<string> ObtenerReporteDespegues()
        {
            List<string> reporteDespegues = new List<string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT IdVuelo, IdPista, IdUsuario, IdInformacionMeteorologica, FechaHora, Descripcion, IdEventoDespegue, IdRegistroComunicacion FROM ReporteFinalDespegues";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int idVuelo = reader.GetInt32(0);
                            int idPista = reader.GetInt32(1);
                            string idUsuario = reader.GetString(2);
                            int idInformacionMeteorologica = reader.GetInt32(3);
                            DateTime fechaHora = reader.GetDateTime(4);
                            string descripcion = reader.GetString(5);
                            int idEventoDespegue = reader.GetInt32(6);
                            int idRegistroComunicacion = reader.GetInt32(7);

                            string despegueInfo = $"IdVuelo: {idVuelo}, IdPista: {idPista}, IdUsuario: {idUsuario}, IdInformacionMeteorologica: {idInformacionMeteorologica}, FechaHora: {fechaHora}, Descripcion: {descripcion}, IdEventoDespegue: {idEventoDespegue}, IdRegistroComunicacion: {idRegistroComunicacion}";
                            reporteDespegues.Add(despegueInfo);
                        }
                    }
                }
            }

            return reporteDespegues;
        }

        public void EnviarMensaje(string mensaje, int idAvion, int idControlador, DateTime fechaHora)
        {
            // Obtener el pr�ximo ID �nico
            int idMensaje = GetNextId();

            // Establecer la conexi�n a la base de datos
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Consulta para insertar un nuevo mensaje en la tabla de Comunicaciones
                string query = "INSERT INTO Comunicaciones (IdComunicacion, FechaHora, IdAvion, IdControlador, ContenidoMensaje) VALUES (@IdComunicacion, @FechaHora, @IdAvion, @IdControlador, @ContenidoMensaje)";

                // Crear el comando SQL con par�metros
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agregar los par�metros
                    command.Parameters.AddWithValue("@IdComunicacion", idMensaje);
                    command.Parameters.AddWithValue("@FechaHora", fechaHora);
                    command.Parameters.AddWithValue("@IdAvion", idAvion);
                    command.Parameters.AddWithValue("@IdControlador", idControlador);
                    command.Parameters.AddWithValue("@ContenidoMensaje", mensaje);

                    // Ejecutar la consulta
                    command.ExecuteNonQuery();
                }
            }
        }

        public int GetNextId()
        {
            int nextId = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT MAX(IdComunicacion) FROM Comunicaciones";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    var result = command.ExecuteScalar();

                    if (result != DBNull.Value)
                    {
                        nextId = Convert.ToInt32(result) + 1;
                    }
                    else
                    {
                        // Si la tabla est� vac�a, comenzar desde 1
                        nextId = 1;
                    }
                }
            }

            return nextId;
        }
    }
}
