﻿// Models/DatosMuestra.cs
using System;
using System.Collections.Generic;
using System.Data;

namespace SkyGuardian.Models
{
    public static class DatosMuestra
    {
        public static DataTable ObtenerDatosMuestra()
        {
            DataTable dataTable = new DataTable();

            // Definir las columnas
            dataTable.Columns.Add("NumeroVuelo", typeof(string));
            dataTable.Columns.Add("salida", typeof(string));
            dataTable.Columns.Add("destino", typeof(string));
            dataTable.Columns.Add("horaDespegue", typeof(DateTime));
            dataTable.Columns.Add("pistaAsignada", typeof(string));
            dataTable.Columns.Add("estadoVuelo", typeof(string));

            // Agregar filas de muestra
            dataTable.Rows.Add("V001", "San José", "Londres", DateTime.Now.AddHours(1), "Pista 1", "En vuelo");
            dataTable.Rows.Add("V002", "San José", "Madrid", DateTime.Now.AddHours(2), "Pista 2", "Programado");
            dataTable.Rows.Add("V003", "San José", "Nueva York", DateTime.Now.AddHours(3), "Pista 3", "Retrasado");
            dataTable.Rows.Add("V004", "San José", "Dubai", DateTime.Now.AddHours(4), "Pista 4", "En vuelo");

            return dataTable;
        }
    }
}
