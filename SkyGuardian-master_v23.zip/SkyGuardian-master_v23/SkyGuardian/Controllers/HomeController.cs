﻿using System.Collections.Generic;
using System.Data;
using System.Web.Mvc;
using SkyGuardian.Models;

namespace SkyGuardian.Controllers
{
    public class HomeController : Controller
    {


        private ConexionBD conexionBD;  // Declarar el objeto conexionBD aquí

        public HomeController()
        {
            conexionBD = new ConexionBD();
        }


        public ActionResult Index()
        {
            var dataTable = conexionBD.ConsultarDatosVuelos();
            return View(dataTable);
        }
        //**************************************************
        public ActionResult Despegues()
        {
            // Obtener la lista de vuelos
            pruebaBD vuelosModel = new pruebaBD();
            List<Vuelo> vuelos = vuelosModel.LeerVuelos();
            ViewData["Vuelos"] = vuelos;

            // Obtener la lista de aviones
            pruebaBD avionesModel = new pruebaBD();
            List<Avion> aviones = avionesModel.LeerAviones();
            ViewData["Aviones"] = aviones;

            return View();
        }


        pruebaBD modelo = new pruebaBD();

        // Método de acción para obtener origen y destino por número de vuelo
        public ActionResult ObtenerOrigenYDestinoPorNumeroVuelo(string numeroVuelo)
        {
            var datosVuelo = modelo.ObtenerOrigenYDestinoPorNumeroVuelo(numeroVuelo);
            return Json(datosVuelo, JsonRequestBehavior.AllowGet); // Devuelve el origen y destino como JSON
        }


        public ActionResult ObtenerDatosAvion(int idAvion)
        {
            var datosAvion = modelo.ObtenerDatosAvion(idAvion);
            return Json(datosAvion, JsonRequestBehavior.AllowGet); // Devuelve el origen y destino como JSON
        }

 

        //***************************************************

        public ActionResult Comunicaciones()
        {
            // Crear una instancia del modelo de comunicaciones
            var model = new ComunicacionesModel();

            // Obtener mensajes de comunicaciones
            var mensajesComunicaciones = model.ObtenerMensajesComunicaciones();

            // Obtener datos de ReporteFinalDespegues
            var reporteDespegues = model.ObtenerReporteDespegues();

            // Pasar los datos a la vista
            ViewBag.MensajesComunicaciones = mensajesComunicaciones;
            ViewBag.ReporteDespegues = reporteDespegues;

            return View();
        }





        public ActionResult About()
        {
            ConexionBD conexion = new ConexionBD();
            DataTable datosVuelos = conexion.ConsultarDatosVuelos();

            return View(datosVuelos);
        }


        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult IniciarSesion()
        {
            ViewBag.Message = "Pagina de Inicio de sesión.";

            return View();
        }

        public ActionResult Registrarse()
        {
            pruebaBD EventosDespegue = new pruebaBD();
            string todo = EventosDespegue.LeerDespegues();
            ViewData["EventosDespegue"] = todo;
            return View();

        }


        public ActionResult ObtenerDetallesAvion(int vueloId)
        {
            var dataTable = conexionBD.ConsultarAvionPorId(vueloId);  // Llamada al nuevo método para buscar el avión por Id
            var avion = new
            {
                idAvion = dataTable.Rows[0]["IdAvion"],
                Modelo = dataTable.Rows[0]["Modelo"],
                Fabricante = dataTable.Rows[0]["Fabricante"],
                AnioFabricacion = dataTable.Rows[0]["AnioFabricacion"],
                CapacidadPasajeros = dataTable.Rows[0]["CapacidadPasajeros"],
                CapacidadCarga = dataTable.Rows[0]["CapacidadCarga"],
                TipoMotor= dataTable.Rows[0]["TipoMotor"],
                Longitud = dataTable.Rows[0]["Longitud"],
                Envergadura = dataTable.Rows[0]["Envergadura"],
                Altura = dataTable.Rows[0]["Altura"],
                //IdEstadoAvion = dataTable.Rows[0]["IdEstadoAvion"],
                CapacidadCombustible = dataTable.Rows[0]["CapacidadCombustible"]
            };

            return Json(avion, JsonRequestBehavior.AllowGet);
        }




    }
}
