﻿using SkyGuardian.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Web.Mvc;

namespace SkyGuardian.Controllers
{
    public class ComunicacionesController : Controller
    {
        private ComunicacionesModel _comunicacionesModel = new ComunicacionesModel();

        // Método para enviar un mensaje
        [HttpPost]
        public ActionResult EnviarMensaje(string mensaje)
        {
            DateTime fechaHora = DateTime.Now;
            int idAvion = 1;
            int idControlador = 1;

            string respuesta;

            // Verificar si el mensaje es un comando
            if (mensaje.StartsWith("/"))
            {
                // Procesar el comando y obtener la respuesta
                respuesta = ProcesarComando(mensaje);
            }
            else
            {
                // Si no es un comando, enviarlo como mensaje normal
                respuesta = "Mensaje enviado: " + mensaje;
            }

            // Guardar el mensaje (comando o mensaje normal) en la base de datos
            _comunicacionesModel.EnviarMensaje(respuesta, idAvion, idControlador, fechaHora);

            return RedirectToAction("Comunicaciones");
        }

        // Método para procesar los comandos
        private string ProcesarComando(string comando)
        {
            comando = comando.Trim().ToLower();

            switch (comando)
            {
                case "/estado":
                    return "El despegue está en curso.";
                case "/clima":
                    return "El clima es soleado y despejado.";
                case "/altitud":
                    return "La altitud actual es de 10,000 pies.";
                case "/ruta":
                    return "La ruta planificada es de San José a Miami.";
                case "/ayuda":
                    return "Comandos disponibles: /estado, /clima, /altitud, /ruta, /ayuda, /aprobardespegue, /reportaremergencia, /atencionabordo, /puertoseguro, /despegar, /tiempo, /combustible, /pista, /destino.";
                case "/aprobardespegue":
                    return "Despegue aprobado.";
                case "/reportaremergencia":
                    return "Se ha reportado una emergencia. Atención requerida.";
                case "/atencionabordo":
                    return "Por favor, presten atención a las instrucciones de seguridad.";
                case "/puertoseguro":
                    return "Aterrizaje de emergencia en el aeropuerto más cercano.";
                case "/despegar":
                    return "Iniciando proceso de despegue.";
                case "/tiempo":
                    return "Tiempo estimado de vuelo: 3 horas.";
                case "/combustible":
                    return "Nivel de combustible actual: 80%.";
                case "/pista":
                    return "Pista asignada para el despegue: 25L.";
                case "/destino":
                    return "Destino final del vuelo: Miami, FL.";
                default:
                    return "Comando no reconocido. Usa /ayuda para ver los comandos disponibles.";
            }
        }
    }
}
