﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SkyGuardian.Controllers
{
    public class DespeguesController : Controller
    {
        // GET: Despegues
        public ActionResult Index()
        {
            return View();
        }
    }
}