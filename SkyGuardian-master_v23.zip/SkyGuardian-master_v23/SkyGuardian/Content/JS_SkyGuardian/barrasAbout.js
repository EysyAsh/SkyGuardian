﻿document.addEventListener("DOMContentLoaded", function () {
    // Array con los porcentajes de cada SkillBar
    var percentages = [80, 15, 10, 10, 80, 10, 30,
        5, 25, 10, 20, 10, 30,
        15, 60, 80, 70, 80, 40];

    // Obtener todas las barras de habilidades por su clase
    var skillBars = document.querySelectorAll(".SkillBar");

    // Iterar sobre cada barra de habilidades
    skillBars.forEach(function (skillBar, index) {
        // Obtener el porcentaje correspondiente
        var percentage = percentages[index];

        // Establecer el ancho de la barra de habilidades
        var skillBarWidth = (percentage / 100) * 90;  // 90% es el ancho máximo definido en CSS
        skillBar.querySelector("#Skills").style.width = skillBarWidth + "%";

        // Actualizar el texto del porcentaje
        var percentText = document.createElement("div");
        percentText.className = "PercentText";
        percentText.textContent = percentage + "%";
        skillBar.insertBefore(percentText, skillBar.firstChild); // Insertar el texto del porcentaje al principio de la barra
    });
});
