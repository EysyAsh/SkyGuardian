﻿function actualizarBarChart(datos) {
    var total = datos.bar1 + datos.bar2 + datos.bar3 + datos.bar4;
    var bar1 = (datos.bar1 / total) * 100;
    var bar2 = (datos.bar2 / total) * 100;
    var bar3 = (datos.bar3 / total) * 100;
    var bar4 = (datos.bar4 / total) * 100;


    document.getElementById('bar1').style.width = bar1 + '%';
    document.getElementById('bar2').style.width = bar2 + '%';
    document.getElementById('bar3').style.width = bar3 + '%';
    document.getElementById('bar4').style.width = bar4 + '%';


    document.getElementById('bar1').querySelector('.bar-text').textContent = 'Asly Martínez - ' + bar1.toFixed(2) + '% - ' + datos.horas1 + 'h';
    document.getElementById('bar2').querySelector('.bar-text').textContent = 'Jorge Martínez - ' + bar2.toFixed(2) + '% - ' + datos.horas2 + 'h';
    document.getElementById('bar3').querySelector('.bar-text').textContent = 'Mauricio Fernández - ' + bar3.toFixed(2) + '% - ' + datos.horas3 + 'h';
    document.getElementById('bar4').querySelector('.bar-text').textContent = 'Grupo - ' + bar4.toFixed(2) + '% - ' + datos.horas4 + 'h';

}

// Ejemplo de uso:
var datos = {
    bar1: 26.93,
    bar2: 31.99,
    bar3: 35.02,
    bar4: 6.04,
    horas1: '53.45',
    horas2: '63.5',
    horas3: '69.5',
    horas4: '12'
};

actualizarBarChart(datos);
