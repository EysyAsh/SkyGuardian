﻿$(document).ready(function () {
    $('input[name="vueloSeleccionado"]').click(function () {
        var vueloId = $(this).data('id');

        // Realizar petición AJAX para obtener detalles del avión
        $.ajax({
            url: '/Home/ObtenerDetallesAvion',
            method: 'GET',
            data: { vueloId: vueloId },
            success: function (data) {
               
                var capacidadCombustible = data.CapacidadCombustible;
                actualizarBarraCarga(capacidadCombustible);
            },
            error: function (error) {
                console.log("Error al obtener detalles del avión:", error);
            }
        });
    });
});

function actualizarBarraCarga(capacidadCombustible) {
    var maxCapacidad = 20000; // Máximo valor de capacidad de combustible
    var porcentaje = (capacidadCombustible / maxCapacidad) * 100;

    $('#CapacidadCombustible').text(capacidadCombustible); // Actualizar el texto
    $('#progress').css('width', porcentaje + '%'); // Actualizar la barra de carga

    // Actualizar el valor de maxCapacidad al final de la barra de progreso
    var textoProgreso = capacidadCombustible + ' litros / ' + maxCapacidad + ' litros';
    $('#progress .progress-text').text(textoProgreso);
}

