﻿document.addEventListener("DOMContentLoaded", function () {
    // Obtener referencia al botón y a la sección
    var boton = document.querySelector(".botonIniciarJornada");
    var seccion = document.getElementById("seccionDeDatosBD");

    // Añadir evento click al botón
    boton.addEventListener("click", function () {
        // Verificar el estado actual de la sección
        if (seccion.style.display === "none" || seccion.style.display === "") {
            // Mostrar la sección
            seccion.style.display = "block";
        } else {
            // Ocultar la sección
            seccion.style.display = "none";
        }
    });
});
