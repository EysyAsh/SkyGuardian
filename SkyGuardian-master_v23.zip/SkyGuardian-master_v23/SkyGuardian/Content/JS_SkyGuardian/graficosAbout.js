﻿// Función para actualizar el gráfico circular con un nuevo porcentaje
function actualizarGraficoCircular(identificador, porcentaje, horas) {
    var longitudTrazo = (porcentaje * 100) / 100;
    var longitudEspacio = 100 - longitudTrazo;

    // Selecciona los elementos específicos basados en el identificador
    var circle = $('.circle-chart__circle[data-id="' + identificador + '"]');
    var percent = $('.circle-chart__percent[data-id="' + identificador + '"]');
    var subline = $('.circle-chart__subline[data-id="' + identificador + '"]');

    // Cambia el color del círculo basado en el identificador
    switch (identificador) {
        case 'GraficoHorasAsly':
            circle.attr('stroke', '#E67598'); 
            break;
        case 'GraficoHorasJorge':
            circle.attr('stroke', '#2D8EB9');
            break;
        case 'GraficoHorasMauricio':
            circle.attr('stroke', '#232025');
            break;
    }

    circle.attr('stroke-dasharray', longitudTrazo + ',100');
    percent.text(porcentaje.toFixed(2) + '%');
    subline.text(horas + ' horas');
}

// Llama a la función para actualizar los gráficos con nuevos porcentajes y horas
actualizarGraficoCircular('GraficoHorasAsly', 26.93, '53.45');
actualizarGraficoCircular('GraficoHorasJorge', 31.99, '63.5');
actualizarGraficoCircular('GraficoHorasMauricio', 35.02, '69.5');
