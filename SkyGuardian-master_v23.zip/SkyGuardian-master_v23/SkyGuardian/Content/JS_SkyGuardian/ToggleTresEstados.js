﻿function toggleme(value, flightNumber) {
    let spanId = "estadoVuelo_" + flightNumber;
    let span = document.getElementById(spanId);

    switch (parseInt(value)) {
        case 1:
            span.textContent = "Cancelado";
            break;
        case 2:
            span.textContent = "En espera";
            break;
        case 3:
            span.textContent = "En vuelo";
            break;
    }
}
