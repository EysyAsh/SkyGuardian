﻿$(document).ready(function () {
    $('input[name="vueloSeleccionado"]').click(function () {
        var vueloId = $(this).data('id');

        // Realizar petición AJAX para obtener detalles del avión
        $.ajax({
            url: '../Home/ObtenerDetallesAvion',
            method: 'GET',
            data: { vueloId: vueloId },
            dataType: 'json',  // Asegurar que la respuesta sea JSON
            success: function (data) {
                if (data) {
                    mostrarDetallesAvion(data);
                } else {
                    console.log("Los datos del avión no están disponibles.");
                }
            },
            error: function (xhr, status, error) {
                console.log("Error al obtener detalles del avión:", xhr.status, status, error);
            }

        });
    });

    // Función para mostrar los detalles del avión
    function mostrarDetallesAvion(data) {
        $('#IdAvion').text('Avión número ' + data.idAvion);
        $('#Modelo').text(data.Modelo || 'Desconocido');
        $('#Fabricante').text(data.Fabricante || 'Desconocido');
        $('#AnioFabricacion').text(data.AnioFabricacion || 'Desconocido');
        $('#CapacidadPasajeros').text((data.CapacidadPasajeros || 0) + ' pasajeros');
        $('#CapacidadCarga').text((data.CapacidadCarga || 0) + ' kg');
        $('#TipoMotor').text(data.TipoMotor || 'Desconocido');
        $('#Longitud').text((data.Longitud || 0) + ' m');
        $('#Envergadura').text((data.Envergadura || 0) + ' m');
        $('#Altura').text((data.Altura || 0) + ' m');
        // Comentado para no mostrar un valor que no se recibe
        //$('#IdEstadoAvion').text(data.IdEstadoAvion || 'Desconocido');
        $('#CapacidadCombustible').text((data.CapacidadCombustible || 0) + ' litros');
    }
});
